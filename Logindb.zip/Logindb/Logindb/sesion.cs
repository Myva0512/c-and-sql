﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logindb
{
     public class sesion
    {
        public static int id, id_tipo;
        public  static string usuario, nombre;

    }
}
